<?php

/**
 * This file is part of the Spryker Commerce OS.
 * For full license information, please view the LICENSE file that was distributed with this source code.
 */

namespace Pyz\Zed\CustomAuth\Business;
use Generated\Shared\Transfer\SsoTransfer;
use Spryker\Zed\CustomAuth\Business\CustomAuthFacade as SprykerCustomAuthFacade;

/**
 * @method \Pyz\Zed\CustomAuth\Business\CustomAuthBusinessFactory getFactory()
 * @method \Pyz\Zed\CustomAuth\Persistence\CustomAuthEntityManagerInterface getEntityManager()
 */
class CustomAuthFacade extends SprykerCustomAuthFacade implements CustomAuthFacadeInterface
{
    /**
     * @param \Generated\Shared\Transfer\SsoTransfer $ssoTransfer
     *
     * @return \Spryker\Shared\Kernel\Transfer\TransferInterface
     */
    public function validateSsoToken(SsoTransfer $ssoTransfer):SsoTransfer
    {
        return $this->getEntityManager()->validateSsoToken( $ssoTransfer);
    }
}
