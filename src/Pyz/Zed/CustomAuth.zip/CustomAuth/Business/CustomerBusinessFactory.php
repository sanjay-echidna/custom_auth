<?php

/**
 * This file is part of the Spryker Commerce OS.
 * For full license information, please view the LICENSE file that was distributed with this source code.
 */

namespace Pyz\Zed\CustomAuth\Business;

use Spryker\Zed\CustomAuth\Business\CustomAuthBusinessFactory as SprykerCustomAuthBusinessFactory;

/**
 * @method \Pyz\Zed\CustomAuth\Persistence\CustomAuthQueryContainerInterface getQueryContainer()
 */
class CustomAuthBusinessFactory extends SprykerCustomAuthBusinessFactory
{

}
