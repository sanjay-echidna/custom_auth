<?php

/**
 * This file is part of the Spryker Commerce OS.
 * For full license information, please view the LICENSE file that was distributed with this source code.
 */

namespace Pyz\Zed\CustomAuth;

use Spryker\Zed\CustomAuth\CustomAuthConfig as SprykerCustomAuthConfig;

class CustomAuthConfig extends SprykerCustomAuthConfig
{
    /**
     * @var bool
     */
    protected const PASSWORD_RESET_EXPIRATION_IS_ENABLED = true;

    /**
     * @var int
     */
    protected const MIN_LENGTH_CustomAuth_PASSWORD = 8;

    /**
     * @var int
     */
    protected const MAX_LENGTH_CustomAuth_PASSWORD = 64;

    /**
     * {@inheritDoc}
     *
     * @return array<string>
     */
    public function getCustomAuthPasswordAllowList(): array
    {
        return [
            'change123',
        ];
    }

    /**
     * {@inheritDoc}
     *
     * @return array<string>
     */
    public function getCustomAuthPasswordDenyList(): array
    {
        return [
            'qwerty',
        ];
    }

    /**
     * {@inheritDoc}
     *
     * @return bool
     */
    public function isRestorePasswordValidationEnabled(): bool
    {
        return true;
    }

    /**
     * {@inheritDoc}
     *
     * @return string
     */
    public function getCustomAuthPasswordCharacterSet(): string
    {
        return "/^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[*.!@#$%^&(){}:;\[\]<>,.?\/~_+\-=|])[a-zA-Z0-9*.!@#$%^& (){}:;\[\]<>,.?\/~_+\-=|]*$/";
    }

    /**
     * {@inheritDoc}
     *
     * @return int|null
     */
    public function getCustomAuthPasswordSequenceLimit(): ?int
    {
        return 3;
    }

    /**
     * {@inheritDoc}
     *
     * @return array<string>
     */
    public function getCustomAuthDetailExternalBlocksUrls()
    {
        return [
            'sales' => '/sales/CustomAuth/CustomAuth-orders',
            'notes' => '/CustomAuth-note-gui/index/index',
        ] + parent::getCustomAuthDetailExternalBlocksUrls();
    }

    /**
     * {@inheritDoc}
     *
     * @return bool
     */
    public function isDoubleOptInEnabled(): bool
    {
        return true;
    }

    /**
     * {@inheritDoc}
     *
     * @return string|null
     */
    public function getCustomAuthSequenceNumberPrefix(): ?string
    {
        return 'CustomAuth';
    }
}
