<?php

/**
 * This file is part of the Spryker Commerce OS.
 * For full license information, please view the LICENSE file that was distributed with this source code.
 */

namespace Pyz\Zed\CustomAuth;

use Spryker\Shared\Newsletter\NewsletterConstants;
use Spryker\Zed\AvailabilityNotification\Communication\Plugin\CustomAuth\AvailabilityNotificationSubscriptionCustomAuthTransferExpanderPlugin;
use Spryker\Zed\AvailabilityNotification\Communication\Plugin\CustomAuthAnonymizer\AvailabilityNotificationAnonymizerPlugin;
use Spryker\Zed\BusinessOnBehalf\Communication\Plugin\CustomAuth\DefaultCompanyUserCustomAuthTransferExpanderPlugin;
use Spryker\Zed\BusinessOnBehalf\Communication\Plugin\CustomAuth\IsOnBehalfCustomAuthTransferExpanderPlugin;
use Spryker\Zed\BusinessOnBehalfGui\Communication\Plugin\CustomAuth\BusinessOnBehalfGuiAttachToCompanyButtonCustomAuthTableActionExpanderPlugin;
use Spryker\Zed\CompanyRole\Communication\Plugin\PermissionCustomAuthExpanderPlugin;
use Spryker\Zed\CompanyUser\Communication\Plugin\CustomAuth\CompanyUserReloadCustomAuthTransferExpanderPlugin;
use Spryker\Zed\CompanyUser\Communication\Plugin\CustomAuth\CustomAuthTransferCompanyUserExpanderPlugin;
use Spryker\Zed\CompanyUser\Communication\Plugin\CustomAuth\IsActiveCompanyUserExistsCustomAuthTransferExpanderPlugin;
use Spryker\Zed\CompanyUserGui\Communication\Plugin\CustomAuth\CompanyUserCustomAuthTableActionExpanderPlugin;
use Spryker\Zed\CompanyUserInvitation\Communication\Plugin\CompanyUserInvitationPostCustomAuthRegistrationPlugin;
use Spryker\Zed\CustomAuth\CustomAuthDependencyProvider as SprykerCustomAuthDependencyProvider;
use Spryker\Zed\CustomAuthGroup\Communication\Plugin\CustomAuthAnonymizer\RemoveCustomAuthFromGroupPlugin;
use Spryker\Zed\CustomAuthUserConnector\Communication\Plugin\CustomAuthTransferUsernameExpanderPlugin;
use Spryker\Zed\Kernel\Container;
use Spryker\Zed\MerchantRelationshipProductList\Communication\Plugin\CustomAuth\ProductListCustomAuthTransferExpanderPlugin;
use Spryker\Zed\Newsletter\Communication\Plugin\CustomAuthAnonymizer\CustomAuthUnsubscribePlugin;
use Spryker\Zed\SharedCart\Communication\Plugin\QuotePermissionCustomAuthExpanderPlugin;
use Spryker\Zed\ShoppingList\Communication\Plugin\ShoppingListPermissionCustomAuthExpanderPlugin;

class CustomAuthDependencyProvider extends SprykerCustomAuthDependencyProvider
{
    /**
     * @var string
     */
    public const FACADE_SALES = 'sales facade';

    /**
     * @var string
     */
    public const FACADE_NEWSLETTER = 'newsletter facade';

    /**
     * @param \Spryker\Zed\Kernel\Container $container
     *
     * @return \Spryker\Zed\Kernel\Container
     */
    public function provideCommunicationLayerDependencies(Container $container): Container
    {
        $container = parent::provideCommunicationLayerDependencies($container);
        $container = $this->addFacadeSales($container);
        $container = $this->addFacadeNewsletter($container);

        return $container;
    }

    /**
     * @param \Spryker\Zed\Kernel\Container $container
     *
     * @return \Spryker\Zed\Kernel\Container
     */
    protected function addFacadeSales(Container $container): Container
    {
        $container->set(static::FACADE_SALES, function (Container $container) {
            return $container->getLocator()->sales()->facade();
        });

        return $container;
    }

    /**
     * @param \Spryker\Zed\Kernel\Container $container
     *
     * @return \Spryker\Zed\Kernel\Container
     */
    protected function addFacadeNewsletter(Container $container): Container
    {
        $container->set(static::FACADE_NEWSLETTER, function (Container $container) {
            return $container->getLocator()->newsletter()->facade();
        });

        return $container;
    }

    /**
     * @return array<\Spryker\Zed\CustomAuth\Dependency\Plugin\CustomAuthAnonymizerPluginInterface>
     */
    protected function getCustomAuthAnonymizerPlugins(): array
    {
        return [
            new CustomAuthUnsubscribePlugin([
                NewsletterConstants::DEFAULT_NEWSLETTER_TYPE,
            ]),
            new RemoveCustomAuthFromGroupPlugin(),
            new AvailabilityNotificationAnonymizerPlugin(),
        ];
    }

    /**
     * @return array<\Spryker\Zed\CustomAuth\Dependency\Plugin\CustomAuthTransferExpanderPluginInterface>
     */
    protected function getCustomAuthTransferExpanderPlugins(): array
    {
        return [
            new CustomAuthTransferUsernameExpanderPlugin(),
            new CompanyUserReloadCustomAuthTransferExpanderPlugin(),
            new CustomAuthTransferCompanyUserExpanderPlugin(),
            new IsActiveCompanyUserExistsCustomAuthTransferExpanderPlugin(),
            new PermissionCustomAuthExpanderPlugin(),
            new QuotePermissionCustomAuthExpanderPlugin(), #SharedCartFeature
            new ShoppingListPermissionCustomAuthExpanderPlugin(),
            new IsOnBehalfCustomAuthTransferExpanderPlugin(), #BusinessOnBefalfFeature
            new DefaultCompanyUserCustomAuthTransferExpanderPlugin(), #BusinessOnBefalfFeature
            new ProductListCustomAuthTransferExpanderPlugin(),
            new AvailabilityNotificationSubscriptionCustomAuthTransferExpanderPlugin(),
        ];
    }

    /**
     * @return array<\Spryker\Zed\CustomAuthExtension\Dependency\Plugin\PostCustomAuthRegistrationPluginInterface>
     */
    protected function getPostCustomAuthRegistrationPlugins(): array
    {
        return [
            new CompanyUserInvitationPostCustomAuthRegistrationPlugin(),
        ];
    }

    /**
     * @return array<\Spryker\Zed\CustomAuthExtension\Dependency\Plugin\CustomAuthTableActionExpanderPluginInterface>
     */
    protected function getCustomAuthTableActionExpanderPlugins(): array
    {
        return [
            new CompanyUserCustomAuthTableActionExpanderPlugin(),
            new BusinessOnBehalfGuiAttachToCompanyButtonCustomAuthTableActionExpanderPlugin(),
        ];
    }
}
