<?php

namespace Pyz\Zed\CustomAuth\Persistence;

use Generated\Shared\Transfer\SsoTransfer;
use Orm\Zed\CustomAuth\Persistence\SpyCustomAuthQuery;
use Spryker\Zed\Kernel\Persistence\AbstractEntityManager;

class CustomAuthEntityManager extends AbstractEntityManager implements CustomAuthEntityManagerInterface
{
    /**
     *
     * @param \Generated\Shared\Transfer\SsoTransfer $ssoTransfer
     * @return \Generated\Shared\Transfer\SsoTransfer
     */
    public function validateSsoToken(SsoTransfer $ssoTransfer): SsoTransfer
    {
        $token = $ssoTransfer->getToken();
        if (!$token) {
            $ssoTransfer->setIsValid(false);
            $ssoTransfer->setMessage('No Token is found');
            return $ssoTransfer;
        }

        $CustomAuthEntities = SpyCustomAuthQuery::create()->find();

        foreach ($CustomAuthEntities as $CustomAuthEntity) {
            $email = $CustomAuthEntity->getEmail();
            $hashedEmail = hash('sha256', $email);

            if ($hashedEmail === $token) {
                $ssoTransfer->setIsValid(true);
                $ssoTransfer->setMessage('Token is valid.');
                return $ssoTransfer;
            }
        }

        $ssoTransfer->setIsValid(false);
        $ssoTransfer->setMessage('Invalid token.');
        return $ssoTransfer;
    }
}
