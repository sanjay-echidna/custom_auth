<?php

namespace Pyz\Zed\CustomAuth\Persistence;
use Generated\Shared\Transfer\SsoTransfer;

interface CustomAuthEntityManagerInterface
{
    /**
     * @param \Generated\Shared\Transfer\SsoTransfer $ssoTransfer
     * @return \Generated\Shared\Transfer\SsoTransfer
     */
    public function validateSsoToken(SsoTransfer $ssoTransfer): SsoTransfer;
}