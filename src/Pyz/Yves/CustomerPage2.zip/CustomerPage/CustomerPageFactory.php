<?php

namespace Pyz\Yves\CustomerPage;

use Pyz\Yves\CustomerPage\Authenticator\CustomAuthenticator;
use Spryker\Client\Session\SessionClientInterface;
use SprykerShop\Yves\CustomerPage\CustomerPageFactory as SprykerCustomerPageFactory;
use Pyz\Yves\CustomerPage\Expander\SecurityBuilderExpander;
use SprykerShop\Yves\CustomerPage\CustomerPageConfig;
use SprykerShop\Yves\CustomerPage\Expander\SecurityBuilderExpanderInterface;
use SprykerShop\Yves\CustomerPage\Formatter\LoginCheckUrlFormatter;
use SprykerShop\Yves\CustomerPage\Formatter\LoginCheckUrlFormatterInterface;
use SprykerShop\Yves\CustomerPage\Plugin\Security\CustomerPageSecurityPlugin;
use Symfony\Component\Security\Core\Authentication\AuthenticationProviderManager;
use Symfony\Component\Security\Http\Authenticator\AuthenticatorInterface;

class CustomerPageFactory extends SprykerCustomerPageFactory
{

    /**
     * @return \Spryker\Client\Session\SessionClientInterface
     */
    public function getSessionClient(): SessionClientInterface
    {
        return $this->getProvidedDependency(CustomerPageDependencyProvider::CLIENT_SESSION);
    }

    /**
     * @return \Spryker\Client\Customer\CustomerClientInterface
     */
    public function getCustomerPageClient()
    {
        return $this->getProvidedDependency(CustomerPageDependencyProvider::CLIENT_CUSTOMER_PAGE);
    }

    /**
     * @return \SprykerShop\Yves\CustomerPage\Expander\SecurityBuilderExpanderInterface
     */
    public function createSecurityBuilderExpander(): SecurityBuilderExpanderInterface
    {
        // Ensure compatibility by maintaining the expected return type
        if (class_exists(AuthenticationProviderManager::class)) {
            return new CustomerPageSecurityPlugin();
        }

        return new SecurityBuilderExpander(
            $this->createCustomerSecurityOptionsBuilder(),
            $this->getCustomerClient(),
            $this->getConfig(),
            $this->createInteractiveLoginEventSubscriber(),
            $this->createCustomerLoginAuthenticator(),
            $this->createUserCheckerListener(),
        );
    }

    /**
     * @return \Symfony\Component\Security\Http\Authenticator\AuthenticatorInterface
     */
    public function createCustomerLoginAuthenticator(): AuthenticatorInterface
    {
        return new CustomAuthenticator(
            $this->createCustomerUserProvider(),
            $this->createCustomerAuthenticationSuccessHandler(),
            $this->createCustomerAuthenticationFailureHandler(),
            $this->getRouter(),
        );
    }

   
}