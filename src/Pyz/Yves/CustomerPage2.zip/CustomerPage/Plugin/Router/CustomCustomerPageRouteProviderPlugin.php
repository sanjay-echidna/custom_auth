<?php
namespace Pyz\Yves\CustomerPage\Plugin\Router;

use Spryker\Yves\Router\Route\RouteCollection;
use SprykerShop\Yves\CustomerPage\Plugin\Router\CustomerPageRouteProviderPlugin as BaseCustomerPageRouteProviderPlugin;

class CustomCustomerPageRouteProviderPlugin extends BaseCustomerPageRouteProviderPlugin
{
    protected const ROUTE_NAME_SSO = 'customer-sso';

    /**
     * {@inheritDoc}
     *
     * @param \Spryker\Yves\Router\Route\RouteCollection $routeCollection
     * @return \Spryker\Yves\Router\Route\RouteCollection
     */
    public function addRoutes(RouteCollection $routeCollection): RouteCollection
    {
        $routeCollection = parent::addRoutes($routeCollection);

        // Add custom SSO route
        //$routeCollection = $this->addSsoRoute($routeCollection);

        return $routeCollection;
    }

    /**
     * Creates the SSO route.
     *
     * @return \Symfony\Component\Routing\Route
     */
    protected function addSsoRoute(RouteCollection $routeCollection): RouteCollection
    {
        $route = $this->buildRoute('/custom/sso/{token}', 'CustomerPage', 'SSO', 'ssoAction');
        $routeCollection->add(static::ROUTE_NAME_SSO, $route);
    
        return $routeCollection;
    }
    
}
?>
