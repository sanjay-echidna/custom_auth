<?php

namespace Pyz\Yves\CustomerPage\Plugin\Security;

use Spryker\Yves\Kernel\AbstractPlugin;
use Spryker\Shared\SecurityExtension\Configuration\SecurityBuilderInterface;
use Spryker\Service\Container\ContainerInterface;
use Spryker\Shared\SecurityExtension\Dependency\Plugin\SecurityPluginInterface;

/**
 * @method Pyz\Yves\CustomerPage\CustomerPageFactory getFactory()
 */
class CustomYvesCustomerPageSecurityPlugin extends AbstractPlugin implements SecurityPluginInterface
{
    /**
     * Custom implementation of the extend method.
     *
     * @param \Spryker\Shared\SecurityExtension\Configuration\SecurityBuilderInterface $securityBuilder
     * @param \Spryker\Service\Container\ContainerInterface $container
     *
     * @return \Spryker\Shared\SecurityExtension\Configuration\SecurityBuilderInterface
     */
    public function extend(SecurityBuilderInterface $securityBuilder, ContainerInterface $container): SecurityBuilderInterface
    {
         return $this->getFactory()->createSecurityBuilderExpander()->extend($securityBuilder, $container);
    }
}
