<?php

namespace Pyz\Yves\CustomerPage\Expander;

use Spryker\Shared\SecurityExtension\Configuration\SecurityBuilderInterface;
use Spryker\Service\Container\ContainerInterface;
use SprykerShop\Shared\CustomerPage\CustomerPageConfig as SharedCustomerPageConfig;
use SprykerShop\Yves\CustomerPage\Expander\SecurityBuilderExpander as SprykerSecurityBuilderExpander;
use SprykerShop\Yves\CustomerPage\Plugin\Provider\CustomerUserProvider;

class SecurityBuilderExpander extends SprykerSecurityBuilderExpander
{
    /**
     * @var string
     */
    protected const SECURITY_CUSTOMER_CUSTOM_AUTHENTICATOR = 'security.secured.custom.authenticator';

    /**
     * @param \Spryker\Shared\SecurityExtension\Configuration\SecurityBuilderInterface $securityBuilder
     * @param \Spryker\Service\Container\ContainerInterface $container
     *
     * @return \Spryker\Shared\SecurityExtension\Configuration\SecurityBuilderInterface
     */
    public function extend(SecurityBuilderInterface $securityBuilder, ContainerInterface $container): SecurityBuilderInterface
    {   
        $securityBuilder = parent::addAccessRules($securityBuilder);
        $securityBuilder = parent::addInteractiveLoginEventSubscriber($securityBuilder);
        $securityBuilder = parent::addAccessDeniedHandler($securityBuilder);
        $securityBuilder = $this->addFirewalls($securityBuilder);
        $securityBuilder = $this->addInteractiveLoginEventSubscriber($securityBuilder);
        $this->addAuthenticator($container);

        $this->addUserCheckerListener($securityBuilder);
        $this->addAuthenticator($container);

        return $securityBuilder;
    }

    /**
     * @param \Spryker\Shared\SecurityExtension\Configuration\SecurityBuilderInterface $securityBuilder
     *
     * @return \Spryker\Shared\SecurityExtension\Configuration\SecurityBuilderInterface
     */
    protected function addFirewalls(SecurityBuilderInterface $securityBuilder): SecurityBuilderInterface
    {
        return $securityBuilder->addFirewall(
            SharedCustomerPageConfig::SECURITY_FIREWALL_NAME,
            [
                'pattern' => '^/(en|de|fr)/custom/sso/[a-zA-Z0-9]+$',
                'form' => [
                    'login_path' => '/custom/sso/',
                    // 'check_path' => static::HOMEPAGE_PATH . '/login_check',
                    'authenticators' => [
                        static::SECURITY_CUSTOMER_CUSTOM_AUTHENTICATOR,
                    ],
                ],
                'stateless'=> true,
                // 'authenticator' => static::SECURITY_CUSTOMER_LOGIN_FORM_AUTHENTICATOR,
                'users' => function () {
                    return new CustomerUserProvider();
                },
                'logout' => [
                    'logout_path' => '/logout',
                    'target_url' => '/',
                ],
            ]
        );
    }

    /**
     * @param \Spryker\Service\Container\ContainerInterface $container
     *
     * @return void
     */
    protected function addAuthenticator(ContainerInterface $container): void
    {
        $container->set(static::SECURITY_CUSTOMER_CUSTOM_AUTHENTICATOR, function () {
            return $this->authenticator;
        });
    }
}
