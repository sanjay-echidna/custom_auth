<?php

namespace Pyz\Yves\CustomAuth\Plugin\Security;

use Spryker\Shared\SecurityExtension\Configuration\SecurityBuilderInterface;
use Spryker\Service\Container\ContainerInterface;
use Spryker\Shared\SecurityExtension\Dependency\Plugin\SecurityPluginInterface;
use Spryker\Yves\Kernel\AbstractPlugin;
use Spryker\Yves\Router\Router\ChainRouter;
use SprykerShop\Yves\CustomerPage\Plugin\Provider\CustomerUserProvider;
use SprykerShop\Shared\CustomerPage\CustomerPageConfig as SharedCustomerPageConfig;
use SprykerShop\Yves\CustomerPage\Plugin\Security\CustomerPageSecurityPlugin;
use SprykerShop\Yves\CustomerPage\Plugin\Security\YvesCustomerPageSecurityPlugin;

/**
 *
 * @method \SprykerShop\Yves\CustomerPage\CustomerPageConfig getConfig()
 * @method \Pyz\Yves\CustomAuth\CustomAuthFactory getFactory()
 */
class YvesCustomAuthSecurityPlugin extends YvesCustomerPageSecurityPlugin
{

    /**
     * @var string
     */
    protected const SECURITY_CUSTOMER_CUSTOM_AUTHENTICATOR = 'security.secured.custom.authenticator';

    /**
     * @param \Spryker\Shared\SecurityExtension\Configuration\SecurityBuilderInterface $securityBuilder
     *
     * @return \Spryker\Shared\SecurityExtension\Configuration\SecurityBuilderInterface
     */
    
     /*
    protected function addFirewalls(SecurityBuilderInterface $securityBuilder): SecurityBuilderInterface
    {
        return $securityBuilder->addFirewall(
            SharedCustomerPageConfig::SECURITY_FIREWALL_NAME,
            [
                'anonymous'=>true,
                'pattern' => '^/(en|de|fr)/custom/sso/[a-zA-Z0-9]+$',
                // 'form' => [
                //     'login_path' => '/custom/sso/',
                //     // 'check_path' => static::HOMEPAGE_PATH . '/login_check',
                //     'authenticators' => [
                //         static::SECURITY_CUSTOMER_CUSTOM_AUTHENTICATOR,
                //     ],
                  // ],
                'guard' => [
                    'authenticators' => [
                        static::SECURITY_CUSTOMER_CUSTOM_AUTHENTICATOR,
                    ],
                ],
                'stateless'=> false,
                // 'authenticator' => static::SECURITY_CUSTOMER_LOGIN_FORM_AUTHENTICATOR,
                'users' => function () {
                    return new CustomerUserProvider();
                },
                'logout' => [
                    'logout_path' => '/logout',
                    'target_url' => '/',
                ],
            ]
        );
    }
    */
    
     /**
     * @param \Spryker\Service\Container\ContainerInterface $container
     *
     * @return void
     */
    // protected function addAuthenticator(ContainerInterface $container): void
    // {
    //     $container->set(static::SECURITY_CUSTOMER_CUSTOM_AUTHENTICATOR, function () {
    //         return $this->authenticator;
    //     });
    // }

    /**
     * Custom implementation of the extend method.
     *
     * @param \Spryker\Shared\SecurityExtension\Configuration\SecurityBuilderInterface $securityBuilder
     * @param \Spryker\Service\Container\ContainerInterface $container
     *
     * @return \Spryker\Shared\SecurityExtension\Configuration\SecurityBuilderInterface
     */
    public function extend(SecurityBuilderInterface $securityBuilder, ContainerInterface $container): SecurityBuilderInterface
    {
        return $this->getFactory()->createSecurityBuilderExpander()->extend($securityBuilder, $container);
    }
}
