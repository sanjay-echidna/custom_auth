import './content-collapser.scss';
