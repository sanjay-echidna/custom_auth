import './jumbotron-echidna.scss';
