import './product-configurator.scss';
