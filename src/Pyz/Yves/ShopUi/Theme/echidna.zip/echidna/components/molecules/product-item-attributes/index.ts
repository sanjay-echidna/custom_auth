import './product-item-attributes';
