import './panel-info-item';
