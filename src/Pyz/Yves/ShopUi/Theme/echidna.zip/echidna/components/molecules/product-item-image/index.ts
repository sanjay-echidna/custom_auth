import './product-item-image';
